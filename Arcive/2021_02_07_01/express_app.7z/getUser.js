
const User = require('./models/User');
//const user = require('./models/User');


var user = new User( {name:'ccc',email:'ffff'});
console.log(user );


